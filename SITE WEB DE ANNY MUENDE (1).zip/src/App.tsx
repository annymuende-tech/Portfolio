import { useState, useEffect, useRef, useCallback } from "react"

const assetPathPrefix = "/assets"

// ── New design assets (node 16:4) ──────────────────────────────────────────
const imgStatusDot   = `${assetPathPrefix}/dc300.svg`
const imgArrowDown   = `${assetPathPrefix}/1c8d1.svg`
const imgAboutIcon   = `${assetPathPrefix}/bcbfc.svg`
const imgProfileIcon = `${assetPathPrefix}/e7930.svg`
const imgActiveIcon  = `${assetPathPrefix}/fd912.svg`
const imgSkillsIcon  = `${assetPathPrefix}/caf41.svg`
const imgHtml5       = `${assetPathPrefix}/4b7c7.svg`
const imgCss3        = `${assetPathPrefix}/adfc6.svg`
const imgJs          = `${assetPathPrefix}/f1ab2.svg`
const imgGit         = `${assetPathPrefix}/a7153.svg`
const imgA11y        = `${assetPathPrefix}/5f229.svg`
const imgEco         = `${assetPathPrefix}/a899f.svg`
const imgProjectsIcon= `${assetPathPrefix}/8ec58.svg`
const imgContactIcon = `${assetPathPrefix}/34ee1.svg`
const imgNavHome     = `${assetPathPrefix}/a234f.svg`
const imgNavAbout    = `${assetPathPrefix}/2682b.svg`
const imgNavSkills   = `${assetPathPrefix}/78121.svg`
const imgNavProjects = `${assetPathPrefix}/59e02.svg`
const imgNavContact  = `${assetPathPrefix}/57f02.svg`
const imgSelectChev  = `${assetPathPrefix}/5d0c2.svg`

// ── Portfolio assets (node 12:9) ───────────────────────────────────────────
const imgPortrait   = `${assetPathPrefix}/050e0.png`
const imgProject1   = `${assetPathPrefix}/17684.png`
const imgProject2   = `${assetPathPrefix}/3689b.png`
const imgProject3   = `${assetPathPrefix}/94a03.png`

// ────────────────────────────────────────────────────────────────────────────
type SectionId = "hero" | "about" | "skills" | "projects" | "contact"

const SECTIONS: { id: SectionId; label: string; navIcon: string }[] = [
  { id: "hero",     label: "Accueil",     navIcon: imgNavHome },
  { id: "about",    label: "À propos",    navIcon: imgNavAbout },
  { id: "skills",   label: "Compétences", navIcon: imgNavSkills },
  { id: "projects", label: "Projets",     navIcon: imgNavProjects },
  { id: "contact",  label: "Contact",     navIcon: imgNavContact },
]

const SKILL_ITEMS = [
  { icon: imgHtml5, name: "HTML5",       sub: "Sémantique" },
  { icon: imgCss3,  name: "CSS3",        sub: "Responsive" },
  { icon: imgJs,    name: "JavaScript",  sub: "Vanilla" },
  { icon: imgGit,   name: "Git",         sub: "Versionnage" },
  { icon: imgA11y,  name: "Accessibilité", sub: "WCAG AAA" },
  { icon: imgEco,   name: "Sobriété",    sub: "Écoconception" },
]

const PROJECTS = [
  {
    tag: "PROJET #01 — GREEN IT",  badge: "Score 100/100",
    title: "Boutique Locale Kin Market",
    desc: "Site vitrine et catalogue léger conçu pour une boutique de détail à Gombe. Score PageSpeed 100/100, requêtes HTTP minimisées et zéro asset superflu.",
    img: imgProject1, imgAlt: "Kin Market",
  },
  {
    tag: "PROJET #02 — DOM & ARIA", badge: "Zéro Dépendance",
    title: "Plateforme Événements Kinshasa",
    desc: "Plateforme répertoriant ateliers, conférences et événements culturels. Application JS manipulant le DOM sans framework lourd, accessibilité ARIA complète.",
    img: imgProject2, imgAlt: "Événements Kinshasa",
  },
  {
    tag: "PROJET #03 — RESPONSIVE DESIGN", badge: "WCAG 2.2 AA",
    title: "Cabinet Juridique Kinshasa",
    desc: "Page d'atterrissage institutionnelle respectant les normes d'accessibilité WCAG 2.2 AA/AAA et compatibilité multi-écrans fluide avec Grid et Flexbox.",
    img: imgProject3, imgAlt: "Cabinet Juridique",
  },
]

// ── Fade-in hook ─────────────────────────────────────────────────────────────
function useFadeIn() {
  const ref = useRef<HTMLDivElement>(null)
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    const el = ref.current
    if (!el) return
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setVisible(true); obs.disconnect() }
    }, { threshold: 0.1 })
    obs.observe(el)
    return () => obs.disconnect()
  }, [])
  return { ref, visible }
}

function FadeSection({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, visible } = useFadeIn()
  return (
    <div
      ref={ref}
      className={`transition-all duration-700 ease-out ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-6"} ${className}`}
    >
      {children}
    </div>
  )
}

// ── Ripple button ─────────────────────────────────────────────────────────────
function RippleButton({ children, className = "", onClick }: {
  children: React.ReactNode; className?: string; onClick?: () => void
}) {
  const [ripples, setRipples] = useState<{ x: number; y: number; id: number }[]>([])
  const btnRef = useRef<HTMLButtonElement>(null)

  function handleClick(e: React.MouseEvent) {
    const rect = btnRef.current?.getBoundingClientRect()
    if (!rect) return
    const id = Date.now()
    setRipples(r => [...r, { x: e.clientX - rect.left, y: e.clientY - rect.top, id }])
    setTimeout(() => setRipples(r => r.filter(rr => rr.id !== id)), 600)
    onClick?.()
  }

  return (
    <button
      ref={btnRef}
      onClick={handleClick}
      className={`relative overflow-hidden select-none ${className}`}
    >
      {ripples.map(r => (
        <span
          key={r.id}
          className="absolute rounded-full bg-white/30 animate-ping pointer-events-none"
          style={{ left: r.x - 20, top: r.y - 20, width: 40, height: 40 }}
        />
      ))}
      {children}
    </button>
  )
}

// ────────────────────────────────────────────────────────────────────────────
export default function App() {
  const [active, setActive] = useState<SectionId>("hero")
  const [menuOpen, setMenuOpen] = useState(false)
  const [form, setForm] = useState({ name: "", email: "", type: "Création de site vitrine éco-conçu", message: "" })
  const [sent, setSent] = useState(false)
  const [expandedProject, setExpandedProject] = useState<number | null>(null)

  // Track scroll → update active section
  useEffect(() => {
    const onScroll = () => {
      for (const s of [...SECTIONS].reverse()) {
        const el = document.getElementById(s.id)
        if (el && window.scrollY >= el.offsetTop - 120) { setActive(s.id); break }
      }
    }
    window.addEventListener("scroll", onScroll, { passive: true })
    return () => window.removeEventListener("scroll", onScroll)
  }, [])

  const scrollTo = useCallback((id: SectionId) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" })
    setMenuOpen(false)
  }, [])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setSent(true)
    setForm({ name: "", email: "", type: "Création de site vitrine éco-conçu", message: "" })
    setTimeout(() => setSent(false), 5000)
  }

  return (
    <div className="min-h-screen pb-16 md:pb-0" style={{ background: "#fbf9f7", fontFamily: "'Libre Baskerville', Georgia, serif" }}>

      {/* ── Desktop header ──────────────────────────────────────────────── */}
      <header className="hidden md:flex fixed top-0 left-0 right-0 z-50 items-center justify-between px-8 py-4 border-b border-[#e4e2e0] bg-[#fbf9f7]/95 backdrop-blur-sm">
        <button
          onClick={() => scrollTo("hero")}
          className="text-[#1b1c1b] font-bold text-[15px] tracking-tight hover:text-[#013a13] transition-colors"
        >
          DevWeb_Junior
        </button>
        <nav className="flex items-center gap-6">
          {SECTIONS.map(s => (
            <button
              key={s.id}
              onClick={() => scrollTo(s.id)}
              className={`text-[13px] tracking-[0.26px] pb-0.5 border-b transition-all duration-200 ${
                active === s.id
                  ? "text-[#013a13] border-[#013a13] font-bold"
                  : "text-[#414940] border-transparent hover:text-[#1b1c1b] hover:border-[#d3e5d0]"
              }`}
            >
              {s.label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-2 text-[11px] tracking-[0.44px] text-[#526253]">
          <div className="size-[8px] rounded-full bg-[#013a13] animate-pulse" />
          <span style={{ fontFamily: "'JetBrains Mono', monospace" }}>Disponible</span>
        </div>
      </header>

      {/* ── Mobile header ───────────────────────────────────────────────── */}
      <header className="md:hidden fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-4 py-3 border-b border-[#e4e2e0] bg-[#fbf9f7]/95 backdrop-blur-sm">
        <button onClick={() => scrollTo("hero")} className="text-[#1b1c1b] font-bold text-[14px]">DevWeb_Junior</button>
        <button
          onClick={() => setMenuOpen(o => !o)}
          className="text-[#414940] hover:text-[#013a13] transition-colors p-1"
          aria-label="Menu"
        >
          <div className={`w-5 h-0.5 bg-current mb-1 transition-transform duration-200 ${menuOpen ? "rotate-45 translate-y-1.5" : ""}`} />
          <div className={`w-5 h-0.5 bg-current mb-1 transition-opacity duration-200 ${menuOpen ? "opacity-0" : ""}`} />
          <div className={`w-5 h-0.5 bg-current transition-transform duration-200 ${menuOpen ? "-rotate-45 -translate-y-1.5" : ""}`} />
        </button>
      </header>

      {/* Mobile dropdown menu */}
      {menuOpen && (
        <div className="md:hidden fixed top-[49px] left-0 right-0 z-40 bg-[#fbf9f7] border-b border-[#e4e2e0] shadow-md">
          {SECTIONS.map(s => (
            <button
              key={s.id}
              onClick={() => scrollTo(s.id)}
              className={`w-full text-left px-6 py-4 text-[14px] border-b border-[#e4e2e0] transition-colors ${
                active === s.id ? "text-[#013a13] font-bold bg-[#d3e5d0]/30" : "text-[#1b1c1b] hover:bg-[#f5f3f1]"
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      )}

      <main className="max-w-[768px] mx-auto px-4 pt-20 md:pt-24 pb-24">

        {/* ── HERO ────────────────────────────────────────────────────────── */}
        <section id="hero" className="flex flex-col gap-4 pt-2 pb-16">
          <div className="bg-[#d3e5d0] flex items-center gap-1.5 px-2 py-1 rounded-[2px] w-fit">
            <img src={imgStatusDot} alt="" style={{ width: 10.667, height: 10.667 }} className="block" />
            <span className="text-[#576757] text-[11px] tracking-[0.44px] font-bold">
              [ Empreinte carbone estimée : 0.12g CO2e/vue — ÉcoIndex A ]
            </span>
          </div>

          <h1 className="text-[#1b1c1b] text-[28px] md:text-[32px] font-bold leading-[1.28] tracking-[-0.28px]">
            Développeuse Web — Spécialisée en Écoconception &amp; Performance
          </h1>
          <p className="text-[#414940] text-[16px] leading-[26px]">
            Conceptrice d'expériences web sobres, ultra-rapides et accessibles à tous, respectant les principes d'allègement du DOM et de sobriété numérique.
          </p>

          <div className="flex flex-col sm:flex-row gap-2 pt-1">
            <RippleButton
              onClick={() => scrollTo("projects")}
              className="bg-[#013a13] text-white text-[16px] font-bold px-8 py-3 rounded-[4px] flex items-center gap-2 hover:bg-[#025c1d] active:scale-95 transition-all duration-150 shadow-[0px_1px_4px_rgba(0,0,0,0.04)] group"
            >
              Voir mes projets
              <img src={imgArrowDown} alt="" style={{ width: 17.333, height: 13.333 }} className="block group-hover:translate-x-1 transition-transform duration-200" />
            </RippleButton>
            <RippleButton
              onClick={() => scrollTo("contact")}
              className="bg-[#efeeeb] text-[#1b1c1b] text-[15px] font-bold px-4 py-3 rounded-[2px] hover:bg-[#e4e2e0] active:scale-95 transition-all duration-150"
            >
              Prendre contact
            </RippleButton>
          </div>

          {/* Mini stat row */}
          <div className="flex gap-6 pt-4 flex-wrap">
            {[
              { v: "3", l: "Projets livrés" },
              { v: "100/100", l: "PageSpeed" },
              { v: "WCAG AA", l: "Accessibilité" },
            ].map(({ v, l }) => (
              <div key={l} className="flex flex-col">
                <span className="text-[#013a13] text-[20px] font-bold leading-none">{v}</span>
                <span className="text-[#526253] text-[11px] tracking-[0.44px] mt-0.5" style={{ fontFamily: "'JetBrains Mono', monospace" }}>{l}</span>
              </div>
            ))}
          </div>
        </section>

        {/* ── À PROPOS ────────────────────────────────────────────────────── */}
        <section id="about" className="py-10 border-t border-[#e4e2e0] scroll-mt-20">
          <FadeSection>
            <div className="flex items-center gap-1 pb-4">
              <img src={imgAboutIcon} alt="" style={{ width: 20, height: 20 }} className="block" />
              <h2 className="text-[#1b1c1b] text-[28px] font-bold tracking-[-0.28px] leading-[36px]">À propos</h2>
            </div>

            <div className="bg-[#f5f3f1] flex flex-col sm:flex-row gap-4 items-start p-4 rounded-[4px]">
              {/* Avatar */}
              <div className="flex flex-col items-center shrink-0">
                <div className="bg-[#e4e2e0] rounded-[12px] shadow-[0px_1px_8px_0px_rgba(0,0,0,0.04)] size-28 overflow-hidden flex items-center justify-center relative group cursor-pointer">
                  <img
                    src={imgPortrait}
                    alt="Anny Muende"
                    className="absolute w-full max-w-none left-0 transition-transform duration-500 group-hover:scale-105"
                    style={{ top: "-39.51%", height: "179.02%" }}
                  />
                  <div className="absolute inset-0 bg-white mix-blend-saturation transition-opacity duration-300 group-hover:opacity-0" />
                  <img src={imgProfileIcon} alt="" style={{ width: 32, height: 32 }} className="relative z-10 opacity-0" />
                </div>
                <p className="text-[#526253] text-[11px] tracking-[0.44px] text-center mt-1 font-bold">Anny Muende</p>
              </div>

              <div className="flex flex-col gap-2">
                <p className="text-[#1b1c1b] text-[16px] leading-[26px]">
                  Je suis une développeuse web animée par la recherche constante d'épure et de résilience technique. Mon approche privilégie le HTML sémantique, la réduction des transferts réseau et la suppression active du JavaScript superficiel.
                </p>
                <p className="text-[#414940] text-[16px] leading-[26px]">
                  Formée aux bonnes pratiques Green IT et aux directives du Référentiel Général d'Amélioration de l'Accessibilité (RGAA / WCAG 2.2 niveau AAA), je conçois des interfaces lisibles au contraste rigoureux, adaptées aux terminaux sobres comme aux conditions de réseau limitées.
                </p>
                <div className="flex items-center gap-1.5 pt-1">
                  <img src={imgActiveIcon} alt="" style={{ width: 16.5, height: 15.75 }} className="block" />
                  <span className="text-[#013a13] text-[13px] tracking-[0.26px] font-bold">Pratique active : DOM frugal, zéro tracking passif</span>
                </div>
              </div>
            </div>
          </FadeSection>
        </section>

        {/* ── COMPÉTENCES ─────────────────────────────────────────────────── */}
        <section id="skills" className="py-10 border-t border-[#e4e2e0] scroll-mt-20">
          <FadeSection>
            <div className="flex items-center gap-1 pb-4">
              <img src={imgSkillsIcon} alt="" style={{ width: 20, height: 16 }} className="block" />
              <h2 className="text-[#1b1c1b] text-[28px] font-bold tracking-[-0.28px] leading-[36px]">Compétences</h2>
            </div>
            <p className="text-[#414940] text-[16px] leading-[24px] mb-4">
              Piliers techniques fondamentaux et protocoles de développement durable appliqués au quotidien :
            </p>
            <div className="grid grid-cols-3 gap-1">
              {SKILL_ITEMS.map(({ icon, name, sub }) => (
                <div
                  key={name}
                  className="bg-[#f5f3f1] flex flex-col items-center justify-center min-h-[72px] py-3 px-1 rounded-[2px] cursor-default hover:bg-[#d3e5d0]/40 hover:scale-[1.03] active:scale-95 transition-all duration-200"
                >
                  <img src={icon} alt="" className="block mb-1" style={{ maxWidth: 18, maxHeight: 18 }} />
                  <span className="text-[#1b1c1b] text-[11px] text-center tracking-[0.44px] font-bold leading-[13.75px]">{name}</span>
                  <span className="text-[#414940] text-[11px] text-center leading-[11px]">{sub}</span>
                </div>
              ))}
            </div>
          </FadeSection>
        </section>

        {/* ── PROJETS ─────────────────────────────────────────────────────── */}
        <section id="projects" className="py-10 border-t border-[#e4e2e0] scroll-mt-20">
          <FadeSection>
            <div className="flex items-center gap-1 pb-4">
              <img src={imgProjectsIcon} alt="" style={{ width: 20, height: 16 }} className="block" />
              <h2 className="text-[#1b1c1b] text-[28px] font-bold tracking-[-0.28px] leading-[36px]">Projets</h2>
            </div>

            <div className="flex flex-col gap-4">
              {PROJECTS.map((p, i) => (
                <article
                  key={i}
                  className="bg-[#f5f3f1] rounded-[4px] p-6 flex flex-col gap-2 hover:shadow-md transition-all duration-200 cursor-pointer group"
                  onClick={() => setExpandedProject(expandedProject === i ? null : i)}
                >
                  <div className="flex items-center justify-between">
                    <div className="bg-[#d3e5d0] px-1 py-0.5 rounded-[2px]">
                      <span className="text-[#576757] text-[11px] tracking-[0.44px] font-bold">{p.tag}</span>
                    </div>
                    <span className="text-[#526253] text-[11px] tracking-[0.44px] font-bold">{p.badge}</span>
                  </div>

                  {/* Thumbnail */}
                  <div className={`overflow-hidden rounded-[2px] transition-all duration-500 ${expandedProject === i ? "max-h-48" : "max-h-0"}`}>
                    <div className="h-36 relative bg-[#e4e2e0]">
                      <img
                        src={p.img}
                        alt={p.imgAlt}
                        className="absolute w-full max-w-none left-0 object-cover"
                        style={{ top: "-4.39%", height: "108.78%" }}
                      />
                      <div className="absolute inset-0 bg-white mix-blend-saturation transition-opacity duration-300 group-hover:opacity-50" />
                    </div>
                  </div>

                  <h3 className="text-[#1b1c1b] text-[18px] font-bold leading-[26px]">{p.title}</h3>
                  <p className="text-[#414940] text-[16px] leading-[26px]">{p.desc}</p>

                  <div className="flex items-center gap-1.5 pt-1 min-h-[44px] py-3">
                    <span className="text-[#013a13] text-[15px] tracking-[0.15px] font-bold group-hover:underline transition-all">En savoir plus</span>
                    <span className="text-[#013a13] text-[15px] font-bold group-hover:translate-x-1 transition-transform duration-200 inline-block">→</span>
                  </div>
                </article>
              ))}
            </div>
          </FadeSection>
        </section>

        {/* ── CONTACT ─────────────────────────────────────────────────────── */}
        <section id="contact" className="py-10 border-t border-[#e4e2e0] scroll-mt-20">
          <FadeSection>
            <div className="flex items-center gap-1 pb-4">
              <img src={imgContactIcon} alt="" style={{ width: 20, height: 16 }} className="block" />
              <h2 className="text-[#1b1c1b] text-[28px] font-bold tracking-[-0.28px] leading-[36px]">Contact</h2>
            </div>
            <p className="text-[#414940] text-[16px] leading-[26px] mb-6">
              Vous recherchez une développeuse junior rigoureuse prête à s'investir dans une équipe soucieuse de la qualité logicielle ? Envoyez-moi un message :
            </p>

            {sent ? (
              <div className="bg-[#d3e5d0] border border-[#526253] rounded-[4px] p-6 text-center">
                <p className="text-[#013a13] font-bold text-[16px]">✓ Message envoyé ! Je vous réponds sous 24h ouvrées.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                {[
                  { field: "name",  label: "Nom *",    placeholder: "ex. Alex Muende",          type: "text" },
                  { field: "email", label: "Email *",   placeholder: "noms@domaine.fr",           type: "email" },
                ].map(({ field, label, placeholder, type }) => (
                  <label key={field} className="flex flex-col gap-1">
                    <span className="text-[#1b1c1b] text-[13px] font-bold tracking-[0.26px]">{label}</span>
                    <input
                      type={type}
                      placeholder={placeholder}
                      value={form[field as keyof typeof form]}
                      onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
                      required
                      className="bg-white border border-[#d3d1ce] rounded-[2px] px-3 py-2.5 text-[14px] text-[#1b1c1b] placeholder-[#9c9892] outline-none focus:border-[#013a13] focus:ring-1 focus:ring-[#013a13]/20 transition-all duration-150"
                    />
                  </label>
                ))}

                <label className="flex flex-col gap-1">
                  <span className="text-[#1b1c1b] text-[13px] font-bold tracking-[0.26px]">Message *</span>
                  <textarea
                    placeholder="Votre message..."
                    value={form.message}
                    onChange={e => setForm(f => ({ ...f, message: e.target.value }))}
                    required
                    rows={4}
                    className="bg-white border border-[#d3d1ce] rounded-[2px] px-3 py-2.5 text-[14px] text-[#1b1c1b] placeholder-[#9c9892] outline-none focus:border-[#013a13] focus:ring-1 focus:ring-[#013a13]/20 transition-all duration-150 resize-none"
                  />
                </label>

                <RippleButton
                  className="bg-[#013a13] text-white font-bold text-[16px] min-h-[48px] px-6 py-3 rounded-[4px] hover:bg-[#025c1d] active:scale-[0.98] transition-all duration-150 mt-1"
                >
                  Envoyer le message
                </RippleButton>
              </form>
            )}

            {/* Footer stats */}
            <div className="flex flex-wrap gap-4 justify-center pt-8 text-[#526253] text-[11px] tracking-[0.44px] border-t border-[#e4e2e0] mt-8">
              {[
                { icon: "⚡", label: "0 requête externe" },
                { icon: "●", label: "Radio contraste > 7:1" },
              ].map(({ icon, label }) => (
                <span key={label} className="flex items-center gap-1" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
                  <span>{icon}</span>{label}
                </span>
              ))}
            </div>

            {/* Social links */}
            <div className="flex justify-center gap-6 pt-3">
              <a href="#" className="text-[#1b1c1b] text-[13px] font-bold hover:text-[#013a13] hover:underline transition-colors">GitLab</a>
              <a href="#" className="text-[#1b1c1b] text-[13px] font-bold hover:text-[#013a13] hover:underline transition-colors">LinkedIn</a>
            </div>
            <p className="text-[#526253] text-[11px] text-center mt-2" style={{ fontFamily: "'JetBrains Mono', monospace" }}>
              Mes cours &amp; accessibles · © 2025 DevWeb_Junior · 0 appel externe &amp; CDN zéro
            </p>
          </FadeSection>
        </section>
      </main>

      {/* ── Mobile bottom nav ───────────────────────────────────────────── */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 flex bg-[#fbf9f7] border-t border-[#e4e2e0]">
        {SECTIONS.map(s => (
          <button
            key={s.id}
            onClick={() => scrollTo(s.id)}
            className={`flex-1 flex flex-col items-center justify-center py-2 gap-0.5 transition-colors duration-150 ${
              active === s.id ? "text-[#013a13]" : "text-[#9c9892] hover:text-[#526253]"
            }`}
          >
            <img
              src={s.navIcon}
              alt=""
              className={`block transition-transform duration-200 ${active === s.id ? "scale-110" : ""}`}
              style={{ width: 20, height: 20, opacity: active === s.id ? 1 : 0.5 }}
            />
            <span className="text-[9px] tracking-[0.36px] font-bold leading-none">{s.label.split(" ")[0]}</span>
          </button>
        ))}
      </nav>
    </div>
  )
}
